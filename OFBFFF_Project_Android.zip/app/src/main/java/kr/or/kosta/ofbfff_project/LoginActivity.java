package kr.or.kosta.ofbfff_project;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    //ID,PWD 입력구간
    EditText idText,  pwText;
    String loginId, loginPw;
    SharedPreferences auto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //위에 ActionBar,상태바 삭제위한 코드
        //이 코드는 FullScreen을 추가하기 위한 코드.
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //초기에 밑에 네비게이션바가 있으면 숨기는 기능.
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(
                new View.OnSystemUiVisibilityChangeListener() {
                    @Override
                    public void onSystemUiVisibilityChange(int visibility) {

                        if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {

                            hideNaviBar();

                        }

                    }

                }

        );
        setContentView(R.layout.activity_login);
        idText = (EditText)findViewById(R.id.idText);
        pwText = (EditText)findViewById(R.id.pwText);
        //자동로그인을 하기 위한 부분
        //처음에는 SharedPreferences에 아무런 정보도 없으므로 값을 저장할 키들을 생성한다.
        auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
        // getString의 첫 번째 인자는 저장될 키, 두 번째 인자는 값.
        // 첨엔 값이 없으므로 키값은 원하는 것으로 하고 값을 null을 줌.
        loginId = auto.getString("idText",null);
        loginPw = auto.getString("pwText",null);

        if(loginId!=null&& loginPw!=null){
            //값이 null이 아니라는것은, 자동 로그인이 설정 되었다는 뜻.
            //지금은 예시로 Test,Test123으로 해놨음
            if(loginId.equals("Test")&&loginPw.equals("Test123")){
                //맞으면 토스트팝업.
                Toast.makeText(LoginActivity.this,loginId+"님 자동 로그인입니다.",Toast.LENGTH_SHORT).show();
                //Main페이지로 넘어감.
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                //지도에서 마커를 항시 표기하기위해서 만들어진 부분.
                intent.putExtra("makeNewMarker",1);
                startActivity(intent);
                finish();
            }else{
                Toast.makeText(LoginActivity.this,"아이디 / 비밀번호가 다릅니다.",Toast.LENGTH_SHORT).show();
            }
        }

    }
    //login버튼을 눌렀을 때
    public void loginOnclicked(View view) {
            //로그인 버튼을 누를때는,처음 값을 입력하는 때밖에 없음.왜냐하면 우리는 자동로그인이기때문.
            //역시 Test,Test123으로 설정해놨음.
            if(idText.getText().toString().equals("Test")&& pwText.getText().toString().equals("Test123")){
                auto.edit().putString("idText",idText.getText().toString()).commit();
                auto.edit().putString("pwText",pwText.getText().toString()).commit();
                Toast.makeText(LoginActivity.this,idText.getText().toString()+"님 로그인되었습니다.",Toast.LENGTH_SHORT).show();
                //Main페이지로 넘어감.
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                //지도에서 마커를 항시 표기하기위해서 만들어진 부분.
                intent.putExtra("makeNewMarker",1);
                startActivity(intent);
                finish();
            }else {
                Toast.makeText(LoginActivity.this,"아이디 / 비밀번호가 다릅니다.",Toast.LENGTH_SHORT).show();
            }

        }

    //팝업이나, 다이얼로그가 표시될 때는 하단에 바가 자동으로 표시됨.
    //표시된 이후 자동으로 숨겨지지 않아서 추가한 코드
    //계속 불러오면서 하단바를 없애는거임.
    public void onWindowFocusChanged(boolean hasFocus)
    {
        if (hasFocus)
        {
            hideNaviBar();
        }
    }

    //하단바를 없애는 부분.
    void hideNaviBar()
    {
        if (Build.VERSION.SDK_INT >= 19)
        {
            getWindow().getDecorView().setSystemUiVisibility
                    ( View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_FULLSCREEN );
        }
        else
        {
            getWindow().getDecorView().setSystemUiVisibility
                    ( View.SYSTEM_UI_FLAG_LOW_PROFILE |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION );
        }

    }
}

