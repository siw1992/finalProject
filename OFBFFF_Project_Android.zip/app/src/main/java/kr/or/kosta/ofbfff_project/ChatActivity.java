package kr.or.kosta.ofbfff_project;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ChatActivity extends Activity {

    //리스틉 선언
    private ListView listView;
    private CustomAdapter m_Adapter;

    String data;
    TextView writeText;
    StringBuffer sb;
    SharedPreferences auto;
    //LinearLayout chatLinear;
    int[] arr = new int[]{0,0,0};
    Boolean isCheck;
    double latitude,longitude;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //위에 ActionBar,상태바 삭제위한 코드
        //이 코드는 FullScreen을 추가하기 위한 코드.
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //초기에 밑에 네비게이션바가 있으면 숨기는 기능.
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(
                new View.OnSystemUiVisibilityChangeListener() {
                    @Override
                    public void onSystemUiVisibilityChange(int visibility) {

                        // System.out.println("focus  onSystemUiVisibilityChange " +  visibility);

                        if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {

                            hideNaviBar();

                        }

                    }

                }

        );

        setContentView(R.layout.activity_chat);
        writeText = (TextView) findViewById(R.id.WriteText);
        //채팅 쪽 동적으로 채팅내용을 치기 위한 것.(ScrollView)
        //chatLinear = (LinearLayout)findViewById(R.id.chatLinear);
        sb = new StringBuffer();

        //listview 띄우는 코드
        m_Adapter = new CustomAdapter();
        listView=findViewById(R.id.list_item);
        listView.setAdapter(m_Adapter);

        //현재는 웹이랑 연동되어 있지 않아서
        //가상 데이터 삽입
        m_Adapter.add("hihi",0);
        m_Adapter.add("nice to meet you ",1);


        //intent 위도,경도 받기 위해서
        Intent intent = getIntent();
        latitude = intent.getExtras().getDouble("latitude");
        longitude = intent.getExtras().getDouble("longitude");


    }

    //팝업이나, 다이얼로그가 표시될 때는 하단에 바가 자동으로 표시됨.
    //표시된 이후 자동으로 숨겨지지 않아서 추가한 코드
    //에..나중에 필요하면 쓰도록
    public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus) {
            hideNaviBar();
        }
    }

    void hideNaviBar() {
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility
                    (View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_FULLSCREEN);
        } else {
            getWindow().getDecorView().setSystemUiVisibility
                    (View.SYSTEM_UI_FLAG_LOW_PROFILE |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }

    }

    //뒤로가기 버튼
    public void backOnClicked(View view) {
        hideNaviBar();
        Intent intent = new Intent(ChatActivity.this, MainActivity.class);
        //지도에서 마커를 항시 표기하기위해서 만들어진 부분.
        intent.putExtra("makeNewMarker",1);
        startActivity(intent);
        finish();
    }

    //텍스트 지우는 버튼.
    public void delOnclicked(View view) {
        //공백 위치를 알아내서 마지막에 쓰인 글자를 지움.
        hideNaviBar();
        isCheck=true;
        //한번에 누를 글자는 최대 3개까지 할 예정. 그 이상은 미관상 안예쁨.
        String msg = sb.toString();
        int pos = msg.indexOf(" ");
        int num=0;
        while(pos>-1){
            Log.d("index",arr[num]+" ");
            arr[num]=pos;
            num++;
            pos = msg.indexOf(" ",pos+1);
        }

        for(int i=2;i>-1;i--){
            if(arr[i]!=0&&isCheck==true){
                Log.d("index1",arr[i]+" backspace");
                if(i!=0)
                    sb.delete(arr[i-1]+1,sb.length());
                if(i==0)
                    sb.delete(0,sb.length());
                writeText.setText(sb.toString());
                arr[i]=0;
                isCheck=false;
            }
        }

    }
    public void sendOnclicked(View view) {
        //홈바 지움.
        hideNaviBar();
        //보내는건 오른쪽
        refresh(sb.toString(),1);
        //서버에다가도 값을 보내야합니다.

        //채팅을 보내고나면, StringBuffer과 writeText안에 값을 초기화시킨다.
        sb.setLength(0);
        writeText.setText("");


    }
    //listview에 값 넣는 구간
    private void refresh(String inputValue, int _str){
        m_Adapter.add(inputValue,_str);
        m_Adapter.notifyDataSetChanged();
    }

    //버튼 메세지들
    public void helpOnClicked(View view) {
        String msg = "도와주세요. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }

    public void thanksOncliked(View view) {
        String msg = "감사합니다. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }

    public void gpsOnClicked(View view) {
        String sLatitude = String.format("%.2f",latitude);
        String sLongtitude = String.format("%.2f",longitude);
        String msg = "위치정보["+sLatitude+","+sLongtitude+"]. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }

    public void dangerOnclicked(View view) {
        String msg = "위험합니다. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }

    public void survivorOnClicked(View view) {
        String msg = "생존자발견. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }

    public void endOnClicked(View view) {
        String msg = "상황종료. ";
        int check = checkLength();
        if(check==1)
            writeTextMethod(msg);
        else
            Toast.makeText(ChatActivity.this,"메세지가 3문장 이상 작성되었습니다! 문장을 3문장까지만 작성하세요.",Toast.LENGTH_LONG).show();
    }
    //stringBuffer에 문구를 써줌.
    public void writeTextMethod(String msg) {
        hideNaviBar();
        sb.append(msg);
        writeText.setText(sb.toString());
    }
    //한번에 3개 이상의 문자열을 입력할 수 없게 정해놨기 때문에, 이걸 체크하는 메소드.
    public int checkLength(){
        String msg = sb.toString();
        int pos = msg.indexOf(" ");
        int num=0;
        while(pos>-1){
            arr[num]=pos;
            num++;
            pos = msg.indexOf(" ",pos+1);
        }
        num=0;
        for(int i=0;i<3;i++){
            if(arr[i]!=0){
                num++;
            }
        }
        if(num==3){
            return 0;
        }else{
            return 1;
        }
    }
}
