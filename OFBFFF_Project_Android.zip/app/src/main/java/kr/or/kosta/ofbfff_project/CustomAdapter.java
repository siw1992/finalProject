package kr.or.kosta.ofbfff_project;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {
    //ListContents가 하나씩 저장되어야 할 ArrayList선언
    //-> 리스트뷰의 구성
    private ArrayList<ListContents> m_list;

    public CustomAdapter(){
        //ArrayList 생성
        m_list = new ArrayList<>();
    }

    //방향을 설정할 내부클래스 정의
    public class ListContents{
        String msg;
        int type;
        public ListContents(String msg, int type){
            this.msg = msg;
            this.type = type;
        }
    }
    //외부에서 아이템 추가 요청시 호출되는 메서드
    public void add(String _msg, int _type){
        m_list.add(new ListContents(_msg, _type));
    }

    //삭제 요청시 호출되는 메서드
    public void remove(int _position){
        m_list.remove(_position);
    }

    //달빅에 의해서 호출

    @Override
    public int getCount() { //전체 데이터
        return m_list.size();
    }

    @Override
    public Object getItem(int position) { //항목값을 position으로 받아서 list에서 가져오도록 설정
        return m_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

// ****** 중요 : 실제 UI에서 붙여주는 작업
// getSystemService : 문자열 상수값을 해당 객체화 해주는 메소드 (기억해둘것!)

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();
        //이 아래부터는 내용이 바뀔수 있음
        TextView m_TextView = null;
        LinearLayout layout = null;
        CustomHolder holder = null;

        //여기 아래부터는 구조임
        if(convertView == null){
            //view가 null일 경우 커스텀 레이아웃을 얻어
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.activity_chatitem,parent, false);
            layout = (LinearLayout) convertView.findViewById(R.id.layout);
            m_TextView = (TextView) convertView.findViewById(R.id.text1);


            //CustomHolder에 읽어온 자원을 등록
            holder = new CustomHolder();
            holder.m_TextView = m_TextView;
            holder.layout = layout;
            convertView.setTag(holder);

        }else{
            holder = (CustomHolder) convertView.getTag();
            m_TextView = holder.m_TextView;
            layout = holder.layout;

        }

        // 사용
        m_TextView.setText(m_list.get(position).msg);

        // 방향에 따른 View의 배치
        if(m_list.get(position).type == 0){
            m_TextView.setBackgroundResource(R.drawable.sendchaticonver21);
            m_TextView.setTextSize(15);
            m_TextView.setPadding(20, 10, 10, 10);
            //m_TextView.setBackgroundResource(R.drawable.sendchaticonver21);
            layout.setGravity(Gravity.LEFT);

        }else if(m_list.get(position).type == 1 ){
            m_TextView.setBackgroundResource(R.drawable.getchaticonver21);
            m_TextView.setTextSize(18);
            m_TextView.setPadding(20, 10, 10, 10);
            layout.setGravity(Gravity.RIGHT);

        }
        return convertView;
    }

    private class CustomHolder{
        TextView m_TextView;
        LinearLayout layout;
    }
}
