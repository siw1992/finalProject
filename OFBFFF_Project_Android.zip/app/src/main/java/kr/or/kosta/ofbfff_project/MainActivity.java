package kr.or.kosta.ofbfff_project;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.provider.Telephony;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {
    //맨 위에 안녕하세요 아무개씨 쓸 때 쓰는 TextView
    TextView mainText;
    static Marker currentPositionMarker=null;
    int autoMarker=0;
    //자동로그인을 위한 SharedPreferences. 이거를 사용하면 안드로이드 안에 파일로 아이디, 비밀번호가 들어감.
    SharedPreferences auto;

    //구글맵을 표시하기 위한 변수들
    private GoogleMap mMap;
    static double longitude; //경도
    static double latitude;   //위도
    LocationManager mLM;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //위에 ActionBar,상태바 삭제위한 코드
        //이 코드는 FullScreen을 추가하기 위한 코드.
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        mainText = (TextView) findViewById(R.id.maintext);

        //SharedPreferences에서 파일로 저장된 id값을 가져와서 맨 위에 안녕하세요 OO씨라고 입력
        auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
        mainText.setText("안녕하세요." + auto.getString("idText", null) + "님");


        //Map을 띄우는 부분.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapView);
        mapFragment.getMapAsync(this);
        mLM = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        //자동로그인이 되었을 때, 마커가 제대로 안나오는 경우가 있음 그걸 방지하기위해서.
        Intent intent = getIntent();
        autoMarker = intent.getExtras().getInt("makeNewMarker");
        //실시간으로 지도를 갱신해야하기 때문에 Thread로 지도를 계속 업데이트.
        handler.sendEmptyMessageDelayed(0, 1000);

        //시스템 알림창이 떴는지 확인하는 쓰레드 실행 지금은 임시로 5초단위로 불러냄.
        //handler2.sendEmptyMessageDelayed(0,5000);


        //초기에 밑에 네비게이션바가 있으면 숨기는 기능.
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(
                new View.OnSystemUiVisibilityChangeListener() {
                    @Override
                    public void onSystemUiVisibilityChange(int visibility) {

                        if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {

                            hideNaviBar();
                        }
                    }

                }

        );

    }

    //팝업이나, 다이얼로그가 표시될 때는 하단에 바가 자동으로 표시됨.
    //표시된 이후 자동으로 숨겨지지 않아서 추가한 코드
    //계속 불러오면서 하단바를 없애는거임.
    public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus) {
            hideNaviBar();
        }
    }

    void hideNaviBar() {
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility
                    (View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_FULLSCREEN);
        } else {
            getWindow().getDecorView().setSystemUiVisibility
                    (View.SYSTEM_UI_FLAG_LOW_PROFILE |
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }

    }

    public void chatOnclicked(View view) {
        //버튼을 누를때마다 올라오는 네비게이션바를 없애기 위해서
        hideNaviBar();
        //채팅버튼을 누르면 지도를 벗어나므로 Marker에 null값을 넣어서 다시 돌아왔을떄 새로 만들 수 있게 한다.
        currentPositionMarker=null;
        //지도를 업데이트 하지 않아도 되기 때문에 handler를 종료시킴.
        handler.removeMessages(1);
        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
        intent.putExtra("latitude",latitude);
        intent.putExtra("longitude",longitude);
        startActivity(intent);
        finish();
    }

    public void logoutOnclicked(View view) {
        hideNaviBar();
        //로그아웃을 누르면 SharedPreferences에 파일로 저장된 id,pwd값을 삭제한다.
        auto = getSharedPreferences("auto", Activity.MODE_PRIVATE);
        SharedPreferences.Editor autoLogin = auto.edit();
        autoLogin.putString("idText", "null");
        autoLogin.putString("pwText", "null");
        autoLogin.commit();
        //채팅버튼을 누르면 지도를 벗어나므로 Marker에 null값을 넣어서 다시 돌아왔을떄 새로 만들 수 있게 한다.
        currentPositionMarker=null;
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //위도,경도에 따라서 해당하는 구역의 맵을 표시한다.
        LatLng latLng = new LatLng(latitude,longitude);
            //마커가 없는데도 있다고 표기되서 없는 경우가 있어서 새로 넣었음.
            if(autoMarker==1){
                MarkerOptions options = new MarkerOptions();
                options.position(latLng);
                currentPositionMarker = mMap.addMarker(options);
                Log.d("Marker?","doing");
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
            }
    }

    //Thread. 계속 지도를 업댓시키기 위함.
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                startLoca();
                //자기 자신의 객체를 재귀 호출 해서 무한 반복이 되도록 설정
                //호출 시 인자, 메세지 번호, 지연시간 인자 1/1000초
                handler.sendEmptyMessageDelayed(0, 1000);
            }
        }
    };
    //Notification. 시스템 알림이 오는지 확인하기 위한 Thread
    Handler handler2 = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                alert();
                //자기 자신의 객체를 재귀 호출 해서 무한 반복이 되도록 설정
                //호출 시 인자, 메세지 번호, 지연시간 인자 1/1000초
                //지금은 실험하기 위해서 5초로 설정해둠.
                handler.sendEmptyMessageDelayed(0, 5000);
            }
        }
    };
    //현재 위치를 받는 메소드
    public void startLoca() {
        //GPS Permission때문에 넣었음.GPS가 켜져있지않으면 작동되지않음.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        //check the network provider is enabled.network로 위치 확인하는것.
        if(mLM.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
            //여기로 따지면 거의 실시간으로 위치를 확인함. 근데 쓰레드는 1초마다 되고있어서 사실 이거는 딱히 의미가 없음.
            mLM.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    //위치가 바뀌면 위도,경도를 가져옴.
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    LatLng latLng = new LatLng(latitude,longitude);
                    if(currentPositionMarker==null){
                        Log.d("Marker","Marker Add");
                        MarkerOptions options = new MarkerOptions();
                        options.position(latLng);
                        currentPositionMarker = mMap.addMarker(options);
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
                    }else {
                        currentPositionMarker.setPosition(latLng);
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
                    }

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });
        }else if(mLM.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            //여기로 따지면 거의 실시간으로 위치를 확인함. 근데 쓰레드는 1초마다 되고있어서 사실 이거는 딱히 의미가 없음.
            mLM.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    //위치가 바뀌면 위도,경도를 가져옴.
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    LatLng latLng = new LatLng(latitude,longitude);

                        if(currentPositionMarker==null){
                            MarkerOptions options = new MarkerOptions();
                            options.position(latLng);
                            currentPositionMarker = mMap.addMarker(options);
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
                        }else {
                            currentPositionMarker.setPosition(latLng);
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
                        }

                       // mMap.addMarker(new MarkerOptions().position(latLng));

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }
                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });
        }


    }


    //관제실에서 알람이 울렸는지 계속 확인하는 메소드
    public void alert(){
        //여기에는 URL이 들어가서 만약에 URL을 가져왔을때 안에 값이 있으면 핸드폰에 alert
        //근데 지금은 아직 초반단계이므로 그냥 alert를 띄우기로함.

        String msg = "위험상황 발생";
       // NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this).
      //          setSmallIcon(R.drawable.systemnotificationicon2).setContentTitle("위험 위험!").setContentText(msg);

        //NotificationManager(시스템 알림 해주는 기능)
        final NotificationManager notificationManager = (NotificationManager) MainActivity.this.getSystemService(MainActivity.this.NOTIFICATION_SERVICE);
        /* Notification 관련 내용

         - setSmallIcon : 푸시 알림 왼쪽 그림

 - setTicker : 알람 발생시 잠깐 나오는 텍스트

 - setWhen : 푸시 알림 시간 miliSecond 단위 설정

- setNumber : 확인하지 않은 알림 개수 표시 설정

 - setContetnTitle : 푸시 알림 상단 텍스트(제목)

 - setContentText : 푸시 알림 내용

 - setDefaults : 푸시 알림 발생시 진동, 사운드 등 설정

 - setContentIntent : 푸시 알림 터치시 실행할 작업 인텐트 설정

 - setAutoCancel : 푸시 알림 터치시 자동 삭제 설정

 - setOngoing : 푸시 알림을 지속적으로 띄울 것인지 설정

이것들 이외에도 많은 설정들이 있지만 지금은 가장 기본적인 것들만 사용했습니다.

그리고 안드로이드 기본 예제인 FloationButton에 푸시 알림이 발생하도록 만들어 보았습니다.
         */

        //푸쉬 알림 터치시 실행할 작업 설정
        //이건 아직 쓸지 말지 생각 안해봤음. 채팅으로 바로 가게할지말지 고민중 http://kwongyo.tistory.com/4
        //final Intent intent = new Intent(MainActivity.this.getApplicationContext(),MainActivity.class);
        Intent intent1 = new Intent(MainActivity.this.getApplication(),MainActivity.class);
        intent1.putExtra("makeNewMarker",1);
        final Notification.Builder builder = new Notification.Builder(getApplicationContext());
        //현재 액티비티를 최상으로 올리고, 최상의 액티비티를 제외한 모든 액티비티를 없앤다.

        intent1.addFlags(intent1.FLAG_ACTIVITY_SINGLE_TOP|intent1.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingNotificationIntent = PendingIntent.getActivity(MainActivity.this,0,intent1,PendingIntent.FLAG_UPDATE_CURRENT);
        /*PendingIntent는 일회용 인텐트 같은 개념입니다.
        FLAG_UPDATE_CURRENT - > 만일 이미 생성된 PendingIntent가 존재 한다면, 해당 Intent의 내용을 변경함.

                FLAG_CANCEL_CURRENT - .이전에 생성한 PendingIntent를 취소하고 새롭게 하나 만든다.

                FLAG_NO_CREATE -> 현재 생성된 PendingIntent를 반환합니다.

        FLAG_ONE_SHOT - >이 플래그를 사용해 생성된 PendingIntent는 단 한번밖에 사용할 수 없습니다
*/
        builder.setSmallIcon(R.drawable.systemnotificationicon2).setTicker("위험 위험!").setWhen(System.currentTimeMillis())
                .setNumber(1).setContentTitle("시스템 알림").setContentText(msg)
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingNotificationIntent).setAutoCancel(true).setOngoing(true);
//setSmallIcon - > 작은 아이콘 이미지

//setTicker - > 알람이 출력될 때 상단에 나오는 문구.

//setWhen -> 알림 출력 시간.

//setContentTitle-> 알림 제목

//setConentText->푸쉬내용
        notificationManager.notify(1,builder.build());//notification send
        Toast.makeText(MainActivity.this,"시스템 알림이 도착했습니다! 상태바를 확인하세요.",Toast.LENGTH_LONG).show();

    }

    }




